exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers, body: "" };
  if (event.httpMethod !== "POST") return { statusCode: 405, headers, body: JSON.stringify({ error: "Sadece POST isteği kabul edilir." }) };

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return { statusCode: 500, headers, body: JSON.stringify({ error: "OPENAI_API_KEY ayarı Netlify'da yapılmamış." }) };

  let message;
  try { message = JSON.parse(event.body || "{}").message; } catch {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "Mesaj okunamadı." }) };
  }
  if (typeof message !== "string" || !message.trim()) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "Lütfen bir mesaj yaz." }) };
  }

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        instructions: "Sen Sünger Dostum adlı sevimli, neşeli, Türkçe konuşan bir sünger karakterisin. Kullanıcıya doğal, kısa ve sıcak cevaplar ver. Küfür edilirse sakin bir sınır koy ama tartışmayı büyütme. Kendini gerçek insan gibi tanıtma. Kullanıcı Türkçe yazarsa Türkçe cevap ver.",
        input: message,
        max_output_tokens: 250
      })
    });
    const data = await response.json();
    if (!response.ok) {
      return { statusCode: response.status, headers, body: JSON.stringify({ error: data.error?.message || "Yapay zekâ API isteği başarısız oldu." }) };
    }
    const reply = (data.output || []).flatMap(item => item.content || []).filter(part => part.type === "output_text").map(part => part.text).join("\n").trim();
    return { statusCode: 200, headers, body: JSON.stringify({ reply: reply || "Bir an aklım karıştı, tekrar söyler misin?" }) };
  } catch (error) {
    return { statusCode: 502, headers, body: JSON.stringify({ error: "Yapay zekâ sunucusuna ulaşılamadı." }) };
  }
};