# Sünger Dostum (Netlify)

## Kurulum
1. `index.html`, `netlify.toml` ve `netlify/functions/chat.js` dosyalarını GitHub deposunun köküne, klasör yapısını koruyarak yükle.
2. Netlify'da **Add new project / Import an existing project** yoluyla GitHub deposunu bağla.
3. Netlify proje ayarlarında **Environment variables** bölümüne `OPENAI_API_KEY` adında değişken ekle ve API anahtarını değer olarak gir. Anahtarı HTML dosyasına veya GitHub'a yazma.
4. Yeniden deploy et. Site HTTPS üzerinden açılınca metin sohbeti kullanılabilir.

İsteğe bağlı: `OPENAI_MODEL` değişkenini `gpt-4.1-mini` olarak ayarlayabilirsin. API kullanımı hesabında ücretlendirmeye tabi olabilir; API erişimi/ödemesi ChatGPT aboneliğinden ayrı olabilir.

## Dosyalar
- `index.html`: Sünger arayüzü, metin sohbeti, tarayıcı seslendirmesi ve mikrofonla konuşma.
- `netlify/functions/chat.js`: API anahtarını sunucu tarafında tutan Netlify Function.
- `netlify.toml`: Netlify yayın ayarları.

Ses tanıma ve seslendirme desteği tarayıcıya/cihaza göre değişebilir; mikrofon izni kullanıcı tarafından verilmelidir.
